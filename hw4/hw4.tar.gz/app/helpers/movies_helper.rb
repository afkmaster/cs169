module MoviesHelper
  # Checks if a number is odd:
  def oddness(count)
  end
end
